<?php
/**
 * The template used for displaying credits
 *
 * @package WEN_Travel
 */
?>

<?php
/**
 * wen_travel_credits hook
 * @hooked wen_travel_footer_content - 10
 */
do_action( 'wen_travel_credits' );
